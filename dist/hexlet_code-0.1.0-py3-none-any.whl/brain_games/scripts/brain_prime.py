#!/usr/bin/env python3
from brain_games.games.prime_engine import func_prime


def main():
    func_prime()


if __name__ == '__main__':
    main()
