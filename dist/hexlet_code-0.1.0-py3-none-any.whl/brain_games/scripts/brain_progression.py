#!/usr/bin/env python3
from brain_games.games.prgss_engine import func_progression


def main():
    func_progression()


if __name__ == '__main__':
    main()
