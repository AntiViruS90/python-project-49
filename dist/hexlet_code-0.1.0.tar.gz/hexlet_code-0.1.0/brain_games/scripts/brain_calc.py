#!/usr/bin/env python3
from brain_games.games.calc_engine import math_calc


def main():
    math_calc()


if __name__ == '__main__':
    main()
