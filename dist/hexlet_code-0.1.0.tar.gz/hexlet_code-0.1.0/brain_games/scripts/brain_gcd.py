#!/usr/bin/env python3
from brain_games.games.gcd_engine import func_gcd


def main():
    func_gcd()


if __name__ == '__main__':
    main()
