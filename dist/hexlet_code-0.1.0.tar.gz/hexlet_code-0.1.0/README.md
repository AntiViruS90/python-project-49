### Hexlet tests and linter status:
[![Actions Status](https://github.com/AntiViruS90/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AntiViruS90/python-project-49/actions)
<a href="https://codeclimate.com/github/AntiViruS90/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d8e7551f540326eecf1e/maintainability" /></a>
